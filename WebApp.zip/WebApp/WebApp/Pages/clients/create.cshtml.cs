using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static WebApp.Pages.clients.IndexModel;

namespace WebApp.Pages.clients
{
    public class createModel : PageModel
    {
        public void OnGet()
        {
        }

        public void onPost()
        {
            clientInfo.name = Request.Form["name"];
            clientInfo.email = Request.Form["email"];
            clientInfo.phone = Request.Form["phone"];
            clientInfo.address = Request.Form["address"];
            
            
            if(clientInfo.name.Lenth==0||clientInfo.email.Lenth==0)|| 
                    clientInfo.phone.Lenth == 0)|| clientInfo.address.Lenth == 0)
                {
                errorMessage = "All the filds are requred";

                return;
                }
        }
    }
}
