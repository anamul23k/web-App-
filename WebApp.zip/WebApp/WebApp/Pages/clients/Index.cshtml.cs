using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace WebApp.Pages.clients
{
    public class IndexModel : PageModel
    {
        public List<clientsInfo> Listclients = new List<clientsInfo>();
        public void OnGet()
        {
            try
            {
                String connectingString = "Data Source=localhost;Initial Catalog=mystore;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectingString))
                {
                    connection.Open();
                    String sql = "select *from clients";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                clientsInfo clientsInfo = new clientsInfo();
                                clientsInfo.id = "" + reader.GetInt32(0);
                                clientsInfo.name = reader.GetString(1);
                                clientsInfo.email = reader.GetString(2);
                                clientsInfo.phone = reader.GetString(3);
                                clientsInfo.address = reader.GetString(4);
                                clientsInfo.created_at = reader.GetDateTime(5).ToString();


                                Listclients.Add(clientsInfo);



                            }
                        }
                    }


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }

        }
        public class clientsInfo
        {
            public String id;
            public String name;
            public String email;
            public String phone;
            public String address;
            public String created_at;
        }
    }
}
